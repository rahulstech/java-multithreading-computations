package cs735_835.computations;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static tinyscalautils.java.Assertions.TODO;

// The class is private, but its name cannot be changed.
class NewThreadComputation<A> implements Computation<A> {

  public static <T> Computation<T> newComputation(Callable<? extends T> task, Runnable... callbacks) {
    return TODO("TO BE IMPLEMENTED");
  }

  public static <T> Computation<List<T>> newComputation(
      List<? extends Callable<? extends T>> tasks,
      Runnable... callbacks
  ) {
    return TODO("TO BE IMPLEMENTED");
  }

  public boolean isFinished() {
    return TODO("TO BE IMPLEMENTED");
  }

  public A get() throws InterruptedException, ExecutionException, CancellationException {
    return TODO("TO BE IMPLEMENTED");
  }

  public void onComplete(Runnable callback) {
    TODO("TO BE IMPLEMENTED");
  }

  public <B> Computation<B> map(Function<? super A, B> f) {
    return TODO("TO BE IMPLEMENTED");
  }

  public <B> Computation<B> mapParallel(Function<? super A, B> f) {
    return TODO("TO BE IMPLEMENTED");
  }
}
