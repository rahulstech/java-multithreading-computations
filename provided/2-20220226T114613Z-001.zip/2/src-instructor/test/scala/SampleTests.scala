import cs735_835.computations.*

class SampleTests
    extends org.scalatest.funsuite.AnyFunSuite
    with SampleTest1
    with SampleTest2
    with SampleTest3
    with SampleTest4
    with SampleTest5
    with SampleTest6
    with SampleTest7
    with SampleTest8
    with SampleTest9
    with SampleTest10
